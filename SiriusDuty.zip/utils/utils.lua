utils = {}

utils.Endpoint = "api.siriusnet.xyz"
utils.APIKey = ""
utils.Telemetry = true




